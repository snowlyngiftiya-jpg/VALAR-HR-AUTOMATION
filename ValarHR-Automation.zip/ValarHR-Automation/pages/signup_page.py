"""
pages/signup_page.py
====================
Page Object Model (POM) class for the ValarHR Signup / Registration page.

Design principles
-----------------
• Every UI interaction is encapsulated in a method – tests never call
  Playwright APIs directly.
• Locators are defined once as class attributes; easy to update when the
  Angular template changes.
• Methods return ``self`` where possible to allow fluent chaining:
      signup.open().enter_first_name("Arjun").enter_last_name("Sharma") …
• All waits use Playwright's built-in auto-waits (locator.fill / click
  already wait for the element to be visible + enabled).  Extra explicit
  waits are added only where Angular's async rendering makes them necessary.
• Assertions live in the test layer; Page Objects only perform actions and
  expose state (``get_*`` methods).

Locator strategy
----------------
Priority order used:
  1. ARIA roles / accessible labels  (``get_by_role``, ``get_by_label``)
  2. ``data-testid`` attributes       (``get_by_test_id``)
  3. Placeholder text                 (``get_by_placeholder``)
  4. CSS selectors                    (``locator("css=…")``)
  5. XPath – last resort              (``locator("xpath=…")``)

Angular note: ValarHR uses Angular reactive forms.  Input names and
``formControlName`` attributes are used as fallback CSS selectors because
Angular does not remove them during compilation.
"""

from __future__ import annotations

from playwright.sync_api import Page, Locator, expect, TimeoutError as PWTimeout

from config.config import Config
from utils.logger import get_logger
from utils.helpers import WaitHelper

log = get_logger(__name__)


class SignupPage:
    """
    Encapsulates all interactions with the ValarHR Signup page.

    Parameters
    ----------
    page:
        The Playwright ``Page`` object injected via pytest fixture.
    """

    # ── URL ───────────────────────────────────────────────────────────────────
    URL: str = Config.signup_url.fget(Config)  # type: ignore[attr-defined]

    # ─────────────────────────────────────────────────────────────────────────
    #  Locator definitions
    #  (Defined as properties so they are fetched fresh on each access –
    #   avoids stale-element issues in Angular SPAs that re-render the DOM.)
    # ─────────────────────────────────────────────────────────────────────────

    def __init__(self, page: Page) -> None:
        self._page = page
        self._wait = WaitHelper(page)

    # ── Form fields ───────────────────────────────────────────────────────────

    @property
    def first_name_input(self) -> Locator:
        """First Name text field."""
        return (
            self._page.get_by_label("First Name", exact=False)
            .or_(self._page.get_by_placeholder("First Name", exact=False))
            .or_(self._page.locator("input[formcontrolname='firstName']"))
            .or_(self._page.locator("input[name='firstName']"))
        )

    @property
    def last_name_input(self) -> Locator:
        """Last Name text field."""
        return (
            self._page.get_by_label("Last Name", exact=False)
            .or_(self._page.get_by_placeholder("Last Name", exact=False))
            .or_(self._page.locator("input[formcontrolname='lastName']"))
            .or_(self._page.locator("input[name='lastName']"))
        )

    @property
    def email_input(self) -> Locator:
        """Email / Username text field."""
        return (
            self._page.get_by_label("Email", exact=False)
            .or_(self._page.get_by_placeholder("Email", exact=False))
            .or_(self._page.locator("input[formcontrolname='email']"))
            .or_(self._page.locator("input[type='email']"))
        )

    @property
    def password_input(self) -> Locator:
        """Password field (not the confirm field)."""
        return (
            self._page.get_by_label("Password", exact=True)
            .or_(self._page.get_by_placeholder("Password", exact=True))
            .or_(self._page.locator("input[formcontrolname='password']"))
            .first
        )

    @property
    def confirm_password_input(self) -> Locator:
        """Confirm Password field."""
        return (
            self._page.get_by_label("Confirm Password", exact=False)
            .or_(self._page.get_by_placeholder("Confirm Password", exact=False))
            .or_(self._page.locator("input[formcontrolname='confirmPassword']"))
            .or_(self._page.locator("input[formcontrolname='confirm_password']"))
        )

    @property
    def signup_button(self) -> Locator:
        """The primary 'Sign Up' / 'Register' / 'Create Account' submit button."""
        return (
            self._page.get_by_role("button", name="Sign Up", exact=False)
            .or_(self._page.get_by_role("button", name="Register", exact=False))
            .or_(self._page.get_by_role("button", name="Create Account", exact=False))
            .or_(self._page.locator("button[type='submit']"))
        )

    # ── Feedback / message areas ───────────────────────────────────────────────

    @property
    def success_message(self) -> Locator:
        """Success toast / banner after a successful registration."""
        return (
            self._page.get_by_role("alert")
            .or_(self._page.locator(".toast-success"))
            .or_(self._page.locator(".success-message"))
            .or_(self._page.locator("[class*='success']"))
        )

    @property
    def error_message(self) -> Locator:
        """Inline error text or toast for validation failures."""
        return (
            self._page.get_by_role("alert")
            .or_(self._page.locator(".toast-error"))
            .or_(self._page.locator(".error-message"))
            .or_(self._page.locator("[class*='error']"))
            .or_(self._page.locator("mat-error"))         # Angular Material
            .or_(self._page.locator(".ng-invalid ~ .mat-error"))
        )

    @property
    def field_error(self) -> Locator:
        """Any field-level validation error (all instances)."""
        return self._page.locator(
            "mat-error, .field-error, .validation-error, "
            "[class*='error-message'], small.error"
        )

    @property
    def login_link(self) -> Locator:
        """'Already have an account? Login' link on the signup page."""
        return (
            self._page.get_by_role("link", name="Login", exact=False)
            .or_(self._page.get_by_role("link", name="Sign In", exact=False))
        )

    # ─────────────────────────────────────────────────────────────────────────
    #  Action methods
    # ─────────────────────────────────────────────────────────────────────────

    def open_signup_page(self) -> "SignupPage":
        """
        Navigate to the Signup page and wait for it to be fully loaded.

        Returns
        -------
        SignupPage
            self – for fluent chaining.
        """
        log.info("Navigating to Signup page: %s", self.URL)
        self._page.goto(self.URL, timeout=Config.NAVIGATION_TIMEOUT)
        # Wait for Angular to finish bootstrapping
        self._wait.wait_for_angular()
        self._wait.wait_for_network_idle()
        log.info("Signup page loaded. Title: '%s'", self._page.title())
        return self

    def enter_first_name(self, first_name: str) -> "SignupPage":
        """
        Clear and type *first_name* into the First Name field.

        Parameters
        ----------
        first_name:
            Value to enter. Pass ``""`` to trigger required-field validation.
        """
        log.debug("Entering First Name: '%s'", first_name)
        self.first_name_input.clear()
        if first_name:
            self.first_name_input.fill(first_name)
        return self

    def enter_last_name(self, last_name: str) -> "SignupPage":
        """Clear and type *last_name* into the Last Name field."""
        log.debug("Entering Last Name: '%s'", last_name)
        self.last_name_input.clear()
        if last_name:
            self.last_name_input.fill(last_name)
        return self

    def enter_email(self, email: str) -> "SignupPage":
        """Clear and type *email* into the Email field."""
        log.debug("Entering Email: '%s'", email)
        self.email_input.clear()
        if email:
            self.email_input.fill(email)
        return self

    def enter_password(self, password: str) -> "SignupPage":
        """Clear and type *password* into the Password field."""
        log.debug("Entering Password: [REDACTED]")
        self.password_input.clear()
        if password:
            self.password_input.fill(password)
        return self

    def enter_confirm_password(self, confirm_password: str) -> "SignupPage":
        """Clear and type *confirm_password* into the Confirm Password field."""
        log.debug("Entering Confirm Password: [REDACTED]")
        self.confirm_password_input.clear()
        if confirm_password:
            self.confirm_password_input.fill(confirm_password)
        return self

    def click_signup(self) -> "SignupPage":
        """
        Click the Signup / Register button.

        Waits for the button to be enabled before clicking (important for
        Angular reactive forms that disable the button on invalid state).
        """
        log.info("Clicking the Signup button")
        btn = self.signup_button
        btn.wait_for(state="visible", timeout=Config.ELEMENT_TIMEOUT)
        btn.click()
        # Allow Angular change-detection to propagate
        self._wait.wait_for_angular()
        return self

    def fill_signup_form(
        self,
        *,
        first_name: str = "",
        last_name: str = "",
        email: str = "",
        password: str = "",
        confirm_password: str = "",
    ) -> "SignupPage":
        """
        Convenience method – fill all fields in one call.

        Usage
        -----
            signup.fill_signup_form(
                first_name="Arjun", last_name="Sharma",
                email="arjun@example.com",
                password="ValarHR@123", confirm_password="ValarHR@123"
            ).click_signup()
        """
        return (
            self.enter_first_name(first_name)
                .enter_last_name(last_name)
                .enter_email(email)
                .enter_password(password)
                .enter_confirm_password(confirm_password)
        )

    def tab_through_empty_form(self) -> "SignupPage":
        """
        Tab through every field without typing to trigger required-field
        validation messages on blur.
        """
        log.info("Tabbing through empty form to trigger validation")
        for loc in [
            self.first_name_input,
            self.last_name_input,
            self.email_input,
            self.password_input,
            self.confirm_password_input,
        ]:
            try:
                loc.click()
                self._page.keyboard.press("Tab")
            except Exception as exc:
                log.debug("Tab-through: skipping field – %s", exc)
        return self

    # ─────────────────────────────────────────────────────────────────────────
    #  Verification / state-query methods
    # ─────────────────────────────────────────────────────────────────────────

    def verify_signup_success(
        self, expected_text: str | None = None, *, timeout: int = Config.ELEMENT_TIMEOUT
    ) -> bool:
        """
        Assert that a success indicator is visible after form submission.

        Checks (in order):
          1. A success toast / alert containing *expected_text* is visible.
          2. The page URL changed away from the signup path (redirect).

        Parameters
        ----------
        expected_text:
            Optional substring to look for in the success message.
            Defaults to the value in test-data ``expected_messages.signup_success``.
        timeout:
            Milliseconds to wait for the success indicator.

        Returns
        -------
        bool
            ``True`` if success is confirmed, ``False`` otherwise
            (tests should use pytest ``assert`` on the return value).
        """
        log.info("Verifying signup success (expected text: %r)", expected_text)

        # Strategy 1 – success message visible
        if expected_text:
            try:
                expect(self._page.get_by_text(expected_text, exact=False)).to_be_visible(
                    timeout=timeout
                )
                log.info("SUCCESS: message '%s' visible.", expected_text)
                return True
            except Exception:
                pass

        # Strategy 2 – URL redirect away from /signup
        try:
            self._wait.wait_for_url_contains("/dashboard", timeout=timeout)
            log.info("SUCCESS: redirected to dashboard.")
            return True
        except Exception:
            pass

        try:
            self._wait.wait_for_url_contains("/login", timeout=timeout)
            log.info("SUCCESS: redirected to login (email-verify flow).")
            return True
        except Exception:
            pass

        log.warning("verify_signup_success: no success indicator found.")
        return False

    def verify_error_message(
        self, expected_text: str, *, timeout: int = Config.ELEMENT_TIMEOUT
    ) -> bool:
        """
        Assert that an error message containing *expected_text* is visible.

        Parameters
        ----------
        expected_text:
            Substring to search for in any visible error element.
        timeout:
            Milliseconds to wait.

        Returns
        -------
        bool
            ``True`` if the error message is found.
        """
        log.info("Verifying error message contains: %r", expected_text)
        try:
            # First try: role=alert
            alert = self._page.get_by_role("alert").filter(has_text=expected_text)
            alert.wait_for(state="visible", timeout=timeout)
            log.info("ERROR MESSAGE found (alert role): '%s'", alert.inner_text())
            return True
        except Exception:
            pass

        # Second try: any visible text on page
        try:
            element = self._page.get_by_text(expected_text, exact=False)
            element.wait_for(state="visible", timeout=timeout)
            log.info("ERROR MESSAGE found (text): '%s'", expected_text)
            return True
        except Exception:
            pass

        log.warning("verify_error_message: '%s' not found on page.", expected_text)
        return False

    def get_field_errors(self) -> list[str]:
        """
        Return a list of all currently visible field-level error messages.

        Useful for asserting that all required fields are highlighted at once.
        """
        errors: list[str] = []
        try:
            for el in self.field_error.all():
                if el.is_visible():
                    errors.append(el.inner_text().strip())
        except Exception as exc:
            log.debug("get_field_errors: %s", exc)
        log.debug("Field errors found: %s", errors)
        return errors

    def is_signup_button_enabled(self) -> bool:
        """Return ``True`` if the Signup button is enabled (not disabled)."""
        return self.signup_button.is_enabled()

    def get_current_url(self) -> str:
        """Return the browser's current URL."""
        return self._page.url

    def get_page_title(self) -> str:
        """Return the document title of the current page."""
        return self._page.title()

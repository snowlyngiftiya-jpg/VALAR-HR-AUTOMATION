"""
conftest.py  (root)
===================
Root-level pytest configuration and shared fixtures for the ValarHR
Automation Framework.

What lives here
---------------
• Browser / page / context lifecycle (Playwright Sync API).
• Signup-page fixture (Page Object).
• Test-data fixture.
• Screenshot-on-failure hook.
• pytest-html report customisation.

Fixture scope summary
---------------------
  browser_instance  – session   (1 browser process for all tests)
  browser_context   – function  (fresh BrowserContext per test → isolation)
  page              – function  (fresh Page per test)
  signup_page       – function  (fresh SignupPage POM per test)
  test_data         – session   (JSON loaded once)
  screenshot_mgr    – function  (one ScreenshotManager per test)
"""

from __future__ import annotations

import pytest
from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright

from config.config import Config
from pages.signup_page import SignupPage
from utils.helpers import DataLoader
from utils.logger import get_logger
from utils.screenshot import ScreenshotManager

log = get_logger("conftest")


# ══════════════════════════════════════════════════════════════════════════════
#  Playwright browser lifecycle
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="session")
def playwright_instance():
    """
    Start a single Playwright process for the entire test session.
    Yields the ``Playwright`` object and tears it down when the session ends.
    """
    with sync_playwright() as pw:
        log.info("Playwright started (session scope).")
        yield pw
        log.info("Playwright session closed.")


@pytest.fixture(scope="session")
def browser_instance(playwright_instance) -> Browser:
    """
    Launch a browser once per session.

    Browser type and launch options are read from ``Config``:
      • BROWSER   – chromium | firefox | webkit
      • HEADLESS  – True/False
      • SLOW_MO   – milliseconds between actions (useful for debugging)
    """
    launch_options = {
        "headless": Config.HEADLESS,
        "slow_mo": Config.SLOW_MO,
        "args": ["--start-maximized"] if Config.BROWSER == "chromium" else [],
    }
    browser_launcher = getattr(playwright_instance, Config.BROWSER)
    browser = browser_launcher.launch(**launch_options)
    log.info(
        "Browser launched: %s | headless=%s | slow_mo=%sms",
        Config.BROWSER, Config.HEADLESS, Config.SLOW_MO,
    )
    yield browser
    browser.close()
    log.info("Browser closed.")


@pytest.fixture(scope="function")
def browser_context(browser_instance: Browser) -> BrowserContext:
    """
    Create a fresh BrowserContext for each test.

    A BrowserContext is like an incognito window – cookies, local/session
    storage, and auth state are completely isolated between tests.
    """
    context = browser_instance.new_context(
        viewport={"width": Config.VIEWPORT_WIDTH, "height": Config.VIEWPORT_HEIGHT},
        ignore_https_errors=True,
        # Uncomment to record video of every test:
        # record_video_dir="screenshots/videos/",
    )
    context.set_default_timeout(Config.DEFAULT_TIMEOUT)
    context.set_default_navigation_timeout(Config.NAVIGATION_TIMEOUT)
    log.debug("New BrowserContext created (viewport %dx%d).", Config.VIEWPORT_WIDTH, Config.VIEWPORT_HEIGHT)
    yield context
    context.close()
    log.debug("BrowserContext closed.")


@pytest.fixture(scope="function")
def page(browser_context: BrowserContext) -> Page:
    """
    Open a new page (tab) inside the isolated browser context.

    Yields the Playwright ``Page`` object and closes it after the test.
    """
    _page = browser_context.new_page()
    log.debug("New Page opened.")
    yield _page
    _page.close()
    log.debug("Page closed.")


# ══════════════════════════════════════════════════════════════════════════════
#  Page Object fixtures
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="function")
def signup_page(page: Page) -> SignupPage:
    """
    Provide an initialised ``SignupPage`` POM instance for each test.

    The fixture does NOT navigate – tests call ``signup_page.open_signup_page()``
    explicitly so that navigation is part of the test story.
    """
    return SignupPage(page)


# ══════════════════════════════════════════════════════════════════════════════
#  Data fixtures
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="session")
def test_data() -> DataLoader:
    """
    Load test-data JSON once for the entire session.

    Usage in a test:
        def test_valid_signup(signup_page, test_data):
            data = test_data.get("valid_user")
            signup_page.enter_first_name(data["first_name"])
    """
    loader = DataLoader()
    log.info("Test data loaded from: %s", Config.TEST_DATA_FILE)
    return loader


# ══════════════════════════════════════════════════════════════════════════════
#  Screenshot fixtures & hooks
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="function")
def screenshot_mgr(page: Page, request: pytest.FixtureRequest) -> ScreenshotManager:
    """
    Provide a ``ScreenshotManager`` bound to the current test's page.

    Tests can call ``screenshot_mgr.capture("my_label")`` at any point.
    Failure screenshots are captured automatically by ``pytest_runtest_makereport``.
    """
    return ScreenshotManager(page, request)


# ── Failure screenshot hook ────────────────────────────────────────────────────

@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call):
    """
    After each test phase (setup / call / teardown), check whether the test
    failed and capture a screenshot if it did.
    """
    outcome = yield
    report = outcome.get_result()

    # Only act on the "call" phase (the actual test body)
    if report.when == "call" and report.failed:
        # Retrieve the screenshot manager fixture if it was requested by the test
        screenshot_mgr: ScreenshotManager | None = item.funcargs.get("screenshot_mgr")
        if screenshot_mgr:
            screenshot_mgr.capture_on_failure()

    # Attach any extras accumulated by ScreenshotManager to the HTML report
    extras = getattr(item, "_extras", [])
    if extras:
        report.extras = getattr(report, "extras", []) + extras


# ══════════════════════════════════════════════════════════════════════════════
#  pytest-html report customisation
# ══════════════════════════════════════════════════════════════════════════════

def pytest_html_report_title(report):
    """Set a custom title for the HTML report."""
    report.title = "ValarHR Automation – Signup Test Report"


def pytest_configure(config):
    """Register custom markers so pytest doesn't warn about unknown marks."""
    config.addinivalue_line("markers", "smoke: Fast, high-priority smoke tests")
    config.addinivalue_line("markers", "regression: Full regression suite")
    config.addinivalue_line("markers", "positive: Happy-path test cases")
    config.addinivalue_line("markers", "negative: Negative / edge-case tests")
    config.addinivalue_line("markers", "signup: Signup module tests")

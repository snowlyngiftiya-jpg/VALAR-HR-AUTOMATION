"""
tests/test_signup.py
====================
Complete Signup (Registration) test suite for ValarHR.

Test categories
---------------
Positive
  TC_SU_001  Successful registration with valid data

Negative
  TC_SU_002  Empty required fields – form should not submit
  TC_SU_003  Invalid email format
  TC_SU_004  Registration with an already-existing email
  TC_SU_005  Password and Confirm-Password mismatch
  TC_SU_006  Weak / common password
  TC_SU_007  Password shorter than the minimum length
  TC_SU_008  Fields at or beyond maximum allowed length
  TC_SU_009  Signup button disabled on empty form (Angular reactive forms)
  TC_SU_010  Parametrised invalid email formats

Each test follows the AAA pattern:
  Arrange – prepare data
  Act     – interact with the page via Page Object methods
  Assert  – verify outcome with explicit assertions + logging
"""

from __future__ import annotations

import pytest

from pages.signup_page import SignupPage
from utils.helpers import DataLoader, RandomData, SoftAssertions
from utils.logger import get_logger
from utils.screenshot import ScreenshotManager

log = get_logger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
#  Positive Test Cases
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.positive
@pytest.mark.signup
@pytest.mark.smoke
class TestSignupPositive:
    """
    Happy-path signup scenarios.
    All tests in this class share the same marker set but run with
    independent fixtures (function-scope browser context).
    """

    def test_TC_SU_001_successful_signup_valid_data(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_001 – Successful registration with valid, unique user data.

        Steps
        -----
        1. Open the Signup page.
        2. Fill all fields with valid data.
        3. Click the Signup button.
        4. Verify success message or redirect to dashboard/login.

        Expected Result
        ---------------
        User is registered; a success message appears OR the page redirects
        to the dashboard or login page (depending on ValarHR's post-signup flow).
        """
        log.info("=== TC_SU_001: Successful Signup with Valid Data ===")

        # ── Arrange ──────────────────────────────────────────────────────────
        data = test_data.get("valid_user")
        expected_msg = test_data.get("expected_messages")["signup_success"]

        # Use Faker to generate a unique email so the test is repeatable
        unique_email = RandomData.email()

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        screenshot_mgr.capture("01_signup_page_loaded")

        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=unique_email,
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        screenshot_mgr.capture("02_form_filled")
        signup_page.click_signup()
        screenshot_mgr.capture("03_after_submit")

        # ── Assert ────────────────────────────────────────────────────────────
        result = signup_page.verify_signup_success(expected_msg)
        assert result, (
            f"TC_SU_001 FAILED: Expected success message '{expected_msg}' "
            f"or a redirect after signup. URL: {signup_page.get_current_url()}"
        )
        log.info("TC_SU_001 PASSED ✓")


# ══════════════════════════════════════════════════════════════════════════════
#  Negative Test Cases
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.negative
@pytest.mark.signup
@pytest.mark.regression
class TestSignupNegative:
    """Negative / edge-case signup scenarios."""

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_002 – Empty required fields
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_002_empty_required_fields(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_002 – Submitting the form with all fields empty.

        Expected Result
        ---------------
        • The form does NOT navigate away from the signup page.
        • At least one required-field validation message is visible.
        """
        log.info("=== TC_SU_002: Empty Required Fields ===")

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.tab_through_empty_form()   # triggers Angular blur validation
        screenshot_mgr.capture("02_empty_form_tabbed")

        # Try clicking submit (Angular may keep it disabled)
        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()
        screenshot_mgr.capture("03_after_empty_submit")

        # ── Assert ────────────────────────────────────────────────────────────
        current_url = signup_page.get_current_url()
        assert "signup" in current_url.lower() or "register" in current_url.lower(), (
            f"TC_SU_002 FAILED: Page navigated away from signup on empty submit. URL: {current_url}"
        )

        errors = signup_page.get_field_errors()
        assert len(errors) > 0, (
            "TC_SU_002 FAILED: No field-level validation errors shown for empty form. "
            f"URL: {current_url}"
        )
        log.info("TC_SU_002 PASSED ✓ – field errors found: %s", errors)

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_003 – Invalid email format (parametrised)
    # ─────────────────────────────────────────────────────────────────────────
    @pytest.mark.parametrize(
        "invalid_email",
        [
            "plaintext",
            "missing@domain",
            "@nodomain.com",
            "double@@at.com",
        ],
        ids=["no_at", "no_tld", "no_local", "double_at"],
    )
    def test_TC_SU_003_invalid_email_format(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
        invalid_email: str,
    ) -> None:
        """
        TC_SU_003 – Registration with malformed email addresses.

        Expected Result
        ---------------
        • An email validation error is displayed.
        • The form does NOT submit successfully.
        """
        log.info("=== TC_SU_003: Invalid Email Format [%s] ===", invalid_email)

        data = test_data.get("valid_user")
        expected_msg = test_data.get("expected_messages")["invalid_email"]

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=invalid_email,
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        # Blur the email field to trigger Angular validation
        signup_page.email_input.blur()
        screenshot_mgr.capture(f"03_invalid_email_{invalid_email[:10]}")

        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()

        # ── Assert ────────────────────────────────────────────────────────────
        current_url = signup_page.get_current_url()
        assert "signup" in current_url.lower() or "register" in current_url.lower(), (
            f"TC_SU_003 FAILED [{invalid_email}]: Page navigated away. URL: {current_url}"
        )

        # Check either an explicit error msg OR that we're still on the page
        error_found = signup_page.verify_error_message(expected_msg)
        if not error_found:
            # Acceptable: Angular's native email validator may use a tooltip /
            # the browser's built-in constraint validation.  Staying on the page is enough.
            log.warning(
                "TC_SU_003 [%s]: Custom error message not found but page did not navigate – PASS (browser validation).",
                invalid_email,
            )
        log.info("TC_SU_003 PASSED ✓ [%s]", invalid_email)

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_004 – Existing email
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_004_existing_email_registration(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_004 – Attempt to register with an email that is already in use.

        Expected Result
        ---------------
        • Server returns a conflict / duplicate-email error.
        • A suitable error message is visible on the page.
        """
        log.info("=== TC_SU_004: Existing Email Registration ===")

        data = test_data.get("existing_user")
        expected_msg = test_data.get("expected_messages")["email_already_exists"]

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=data["email"],
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        screenshot_mgr.capture("04_existing_email_form")
        signup_page.click_signup()
        screenshot_mgr.capture("04_after_existing_email_submit")

        # ── Assert ────────────────────────────────────────────────────────────
        result = signup_page.verify_error_message(expected_msg)
        assert result, (
            f"TC_SU_004 FAILED: Expected error '{expected_msg}' for existing email "
            f"'{data['email']}'. URL: {signup_page.get_current_url()}"
        )
        log.info("TC_SU_004 PASSED ✓")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_005 – Password mismatch
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_005_password_mismatch(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_005 – Password and Confirm Password fields contain different values.

        Expected Result
        ---------------
        • A "passwords do not match" error is shown.
        • Form does not submit.
        """
        log.info("=== TC_SU_005: Password Mismatch ===")

        data = test_data.get("password_mismatch")
        expected_msg = test_data.get("expected_messages")["password_mismatch"]

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=data["email"],
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        signup_page.confirm_password_input.blur()
        screenshot_mgr.capture("05_password_mismatch")

        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()

        # ── Assert ────────────────────────────────────────────────────────────
        result = signup_page.verify_error_message(expected_msg)
        assert result, (
            f"TC_SU_005 FAILED: Expected mismatch error '{expected_msg}'. "
            f"URL: {signup_page.get_current_url()}"
        )
        log.info("TC_SU_005 PASSED ✓")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_006 – Weak password
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_006_weak_password(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_006 – Password that fails complexity rules (all lowercase, no digits/symbols).

        Expected Result
        ---------------
        • A weak-password / strength indicator error appears.
        """
        log.info("=== TC_SU_006: Weak Password ===")

        data = test_data.get("weak_password")
        expected_msg = test_data.get("expected_messages")["weak_password"]

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=RandomData.email(),
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        signup_page.password_input.blur()
        screenshot_mgr.capture("06_weak_password")

        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()

        # ── Assert ────────────────────────────────────────────────────────────
        result = signup_page.verify_error_message(expected_msg)
        assert result, (
            f"TC_SU_006 FAILED: Expected weak-password error '{expected_msg}'. "
            f"URL: {signup_page.get_current_url()}"
        )
        log.info("TC_SU_006 PASSED ✓")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_007 – Minimum password length
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_007_minimum_password_length(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_007 – Password shorter than the minimum required length (e.g. 4 chars).

        Expected Result
        ---------------
        • A minimum-length validation error appears.
        """
        log.info("=== TC_SU_007: Minimum Password Length Validation ===")

        data = test_data.get("short_password")
        expected_msg = test_data.get("expected_messages")["short_password"]

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=RandomData.email(),
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        signup_page.password_input.blur()
        screenshot_mgr.capture("07_short_password")

        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()

        # ── Assert ────────────────────────────────────────────────────────────
        result = signup_page.verify_error_message(expected_msg)
        assert result, (
            f"TC_SU_007 FAILED: Expected short-password error '{expected_msg}'. "
            f"URL: {signup_page.get_current_url()}"
        )
        log.info("TC_SU_007 PASSED ✓")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_008 – Maximum field length validation
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_008_maximum_field_length(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_008 – Fields filled with strings that exceed maximum allowed length.

        Strategy
        --------
        • Fill first_name and last_name with 100-character strings.
        • Verify either:
            a) The input truncates the value (Angular maxlength attribute), OR
            b) A validation error appears.

        Expected Result
        ---------------
        The form enforces maximum length – either by truncation or error message.
        """
        log.info("=== TC_SU_008: Maximum Field Length Validation ===")

        data = test_data.get("max_length")
        soft = SoftAssertions()

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=data["email"],
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        screenshot_mgr.capture("08_max_length_filled")

        # ── Assert ────────────────────────────────────────────────────────────
        first_name_actual = signup_page.first_name_input.input_value()
        last_name_actual  = signup_page.last_name_input.input_value()

        # Either the field truncated the value OR a validation error is shown
        first_truncated = len(first_name_actual) < len(data["first_name"])
        last_truncated  = len(last_name_actual)  < len(data["last_name"])

        errors = signup_page.get_field_errors()
        has_error = len(errors) > 0

        soft.assert_true(
            first_truncated or has_error,
            f"First name: no truncation and no error. Actual length = {len(first_name_actual)}"
        )
        soft.assert_true(
            last_truncated or has_error,
            f"Last name: no truncation and no error. Actual length = {len(last_name_actual)}"
        )
        soft.assert_all()
        log.info("TC_SU_008 PASSED ✓")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_009 – Submit button disabled on empty form
    # ─────────────────────────────────────────────────────────────────────────
    def test_TC_SU_009_signup_button_disabled_when_form_empty(
        self,
        signup_page: SignupPage,
        screenshot_mgr: ScreenshotManager,
    ) -> None:
        """
        TC_SU_009 – The Signup button should be disabled when the form is untouched.

        Angular reactive forms can bind the button's ``[disabled]`` attribute to
        the form's validity state.  This test verifies that safeguard.

        Note: If the application renders the button enabled but relies solely on
        server-side validation, this test is marked xfail with a reason.
        """
        log.info("=== TC_SU_009: Signup Button Disabled on Empty Form ===")

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        screenshot_mgr.capture("09_empty_form_initial")

        # ── Assert ────────────────────────────────────────────────────────────
        is_enabled = signup_page.is_signup_button_enabled()
        if is_enabled:
            # Not all Angular apps disable the button – log a warning but don't fail hard
            log.warning(
                "TC_SU_009: Signup button is ENABLED on empty form. "
                "The app relies on server-side or submit-time validation instead."
            )
            pytest.xfail(
                "Signup button is enabled on an empty form – application uses "
                "submit-time validation rather than reactive form disable."
            )
        else:
            assert not is_enabled, "TC_SU_009 FAILED: Button unexpectedly enabled."
            log.info("TC_SU_009 PASSED ✓ – Button correctly disabled on empty form.")

    # ─────────────────────────────────────────────────────────────────────────
    #  TC_SU_010 – SQL / script injection in name fields
    # ─────────────────────────────────────────────────────────────────────────
    @pytest.mark.parametrize(
        "first_name,last_name",
        [
            ("'; DROP TABLE users;--", "Normal"),
            ("<script>alert('xss')</script>", "XSS"),
            ("Robert'); DROP", "Tables"),
        ],
        ids=["sql_injection", "xss_script_tag", "bobby_tables"],
    )
    def test_TC_SU_010_injection_in_name_fields(
        self,
        signup_page: SignupPage,
        test_data: DataLoader,
        screenshot_mgr: ScreenshotManager,
        first_name: str,
        last_name: str,
    ) -> None:
        """
        TC_SU_010 – Injection / script strings in name fields.

        Expected Result
        ---------------
        • The application does NOT crash, redirect to an error page, or execute
          embedded scripts.
        • It either shows a validation error OR safely displays/rejects the input.
        """
        log.info("=== TC_SU_010: Injection in Name Fields [%s] ===", first_name[:20])

        data = test_data.get("valid_user")

        # ── Act ───────────────────────────────────────────────────────────────
        signup_page.open_signup_page()
        signup_page.fill_signup_form(
            first_name=first_name,
            last_name=last_name,
            email=RandomData.email(),
            password=data["password"],
            confirm_password=data["confirm_password"],
        )
        screenshot_mgr.capture(f"10_injection_{first_name[:10]}")

        if signup_page.is_signup_button_enabled():
            signup_page.click_signup()

        # ── Assert ────────────────────────────────────────────────────────────
        current_url = signup_page.get_current_url()
        page_content = signup_page._page.content()

        # The app must not navigate to an error/500 page
        assert "500" not in current_url and "error" not in current_url.lower(), (
            f"TC_SU_010 FAILED [{first_name}]: Server error page detected. URL: {current_url}"
        )
        # Alert dialogs should not have appeared (Playwright auto-dismisses by default)
        assert "alert('xss')" not in page_content, (
            f"TC_SU_010 FAILED [{first_name}]: XSS payload found in page source."
        )
        log.info("TC_SU_010 PASSED ✓ [%s]", first_name[:20])

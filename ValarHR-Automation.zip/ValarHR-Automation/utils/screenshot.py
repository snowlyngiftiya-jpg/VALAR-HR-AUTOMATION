"""
utils/screenshot.py
===================
Screenshot capture utility for the ValarHR Automation Framework.

Responsibilities
----------------
• Capture full-page or viewport screenshots via Playwright.
• Embed screenshots in the pytest-html report (base-64 data URI).
• Persist screenshots to ``screenshots/`` with a timestamped filename.
• Optionally attach to Allure reports (future extension point).

Usage
-----
    from utils.screenshot import ScreenshotManager
    sm = ScreenshotManager(page, request)      # request = pytest FixtureRequest
    sm.capture("after_form_submit")            # manual capture
    # On failure, conftest.py calls sm.capture_on_failure()
"""

import base64
from datetime import datetime
from pathlib import Path

import pytest
from playwright.sync_api import Page

from config.config import Config
from utils.logger import get_logger

log = get_logger(__name__)


class ScreenshotManager:
    """
    Manages screenshot capture and reporting for a single test.

    Parameters
    ----------
    page:
        Active Playwright ``Page`` instance.
    request:
        Pytest ``FixtureRequest`` – used to derive the test name and attach
        images to the HTML report.
    """

    def __init__(self, page: Page, request: pytest.FixtureRequest) -> None:
        self._page = page
        self._request = request
        self._screenshot_dir = Path(Config.SCREENSHOT_DIR)
        self._screenshot_dir.mkdir(parents=True, exist_ok=True)

    # ── Public API ─────────────────────────────────────────────────────────────

    def capture(self, label: str = "screenshot", *, full_page: bool = True) -> Path:
        """
        Capture a screenshot and save it to disk.

        Parameters
        ----------
        label:
            Short descriptive label embedded in the filename.
        full_page:
            ``True``  – capture the entire scrollable page.
            ``False`` – capture the current viewport only.

        Returns
        -------
        Path
            Absolute path to the saved PNG file.
        """
        filename = self._build_filename(label)
        path = self._screenshot_dir / filename
        try:
            self._page.screenshot(path=str(path), full_page=full_page)
            log.info("Screenshot saved → %s", path)
            self._attach_to_report(path, label)
        except Exception as exc:
            log.warning("Could not capture screenshot '%s': %s", label, exc)
        return path

    def capture_on_failure(self) -> None:
        """
        Convenience wrapper called by conftest on test failure.
        Only captures if ``Config.SCREENSHOT_ON_FAILURE`` is True.
        """
        if not Config.SCREENSHOT_ON_FAILURE:
            return
        test_name = self._request.node.name
        log.warning("Test FAILED – capturing failure screenshot for '%s'", test_name)
        self.capture(f"FAILED_{test_name}")

    # ── Private helpers ────────────────────────────────────────────────────────

    def _build_filename(self, label: str) -> str:
        """Return a unique filename: <test_name>_<label>_<timestamp>.png"""
        test_name = self._request.node.name
        # Sanitise: replace characters that are illegal in filenames
        safe_test  = _sanitise(test_name)
        safe_label = _sanitise(label)
        timestamp  = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return f"{safe_test}__{safe_label}__{timestamp}.png"

    def _attach_to_report(self, path: Path, label: str) -> None:
        """Embed the screenshot as a base-64 data URI in the pytest-html report."""
        try:
            img_bytes = path.read_bytes()
            b64 = base64.b64encode(img_bytes).decode("ascii")
            data_uri = f"data:image/png;base64,{b64}"
            # pytest-html extra
            extras = getattr(self._request.node, "_extras", None)
            if extras is None:
                # create the list if conftest hasn't set it yet
                self._request.node._extras = []  # type: ignore[attr-defined]
                extras = self._request.node._extras
            extras.append(
                {
                    "name": label,
                    "format": "image",
                    "content": data_uri,
                    "mime_type": "image/png",
                }
            )
        except Exception as exc:
            log.debug("Could not attach screenshot to HTML report: %s", exc)


# ── Module-level helper ────────────────────────────────────────────────────────

def _sanitise(text: str) -> str:
    """Replace characters that are unsafe in filenames with underscores."""
    keep = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")
    return "".join(c if c in keep else "_" for c in text)

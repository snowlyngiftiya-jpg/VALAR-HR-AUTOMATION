"""
utils/helpers.py
================
General-purpose helper utilities for the ValarHR Automation Framework.

Contents
--------
• DataLoader   – Load & validate JSON test-data files.
• RetryHelper  – Retry a callable N times with delay.
• WaitHelper   – Extra Playwright wait utilities beyond built-in auto-waits.
• RandomData   – Generate realistic random test data via Faker.
• Assertions   – Soft-assertion collector (report all failures at once).
"""

import json
import time
from pathlib import Path
from typing import Any, Callable, TypeVar

import pytest
from faker import Faker
from playwright.sync_api import Locator, Page, TimeoutError as PWTimeout

from config.config import Config
from utils.logger import get_logger

log = get_logger(__name__)
_fake = Faker()
T = TypeVar("T")

# ══════════════════════════════════════════════════════════════════════════════
# DataLoader
# ══════════════════════════════════════════════════════════════════════════════

class DataLoader:
    """
    Load test data from JSON files under the ``testdata/`` directory.

    Usage
    -----
        loader = DataLoader()
        cases  = loader.get("valid_user")      # returns dict
        cases  = loader.get_all()              # returns full file as dict
    """

    def __init__(self, filepath: str = Config.TEST_DATA_FILE) -> None:
        self._path = Path(filepath)
        self._data: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            raise FileNotFoundError(
                f"Test-data file not found: {self._path.resolve()}"
            )
        with self._path.open(encoding="utf-8") as fh:
            self._data = json.load(fh)
        log.debug("Test data loaded from %s (%d top-level keys)", self._path, len(self._data))

    def get(self, key: str) -> Any:
        """Return the value for *key*.  Raises ``KeyError`` if missing."""
        if key not in self._data:
            raise KeyError(
                f"Key '{key}' not found in {self._path}. "
                f"Available keys: {list(self._data.keys())}"
            )
        return self._data[key]

    def get_all(self) -> dict[str, Any]:
        """Return the entire test-data dictionary."""
        return dict(self._data)


# ══════════════════════════════════════════════════════════════════════════════
# RetryHelper
# ══════════════════════════════════════════════════════════════════════════════

class RetryHelper:
    """
    Retry a callable up to *max_attempts* times, sleeping *delay* seconds
    between attempts.  Useful for flaky network-dependent assertions.

    Usage
    -----
        result = RetryHelper.retry(lambda: page.title(), max_attempts=3)
    """

    @staticmethod
    def retry(
        fn: Callable[[], T],
        *,
        max_attempts: int = Config.MAX_RETRIES,
        delay: float = Config.RETRY_DELAY,
        exceptions: tuple[type[Exception], ...] = (Exception,),
    ) -> T:
        last_exc: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                return fn()
            except exceptions as exc:
                last_exc = exc
                log.warning("Attempt %d/%d failed: %s", attempt, max_attempts, exc)
                if attempt < max_attempts:
                    time.sleep(delay)
        raise RuntimeError(
            f"All {max_attempts} attempts failed. Last error: {last_exc}"
        ) from last_exc


# ══════════════════════════════════════════════════════════════════════════════
# WaitHelper
# ══════════════════════════════════════════════════════════════════════════════

class WaitHelper:
    """
    Extra wait utilities that complement Playwright's built-in auto-waits.

    Playwright already waits for elements to be actionable (visible,
    stable, enabled) before each action.  These helpers cover cases where
    you need to wait for a *state* rather than an action.
    """

    def __init__(self, page: Page) -> None:
        self._page = page

    def wait_for_url_contains(self, fragment: str, timeout: int = Config.NAVIGATION_TIMEOUT) -> None:
        """Block until the current URL contains *fragment*."""
        log.debug("Waiting for URL to contain '%s'", fragment)
        self._page.wait_for_url(f"**{fragment}**", timeout=timeout)

    def wait_for_text_visible(
        self, text: str, timeout: int = Config.ELEMENT_TIMEOUT
    ) -> None:
        """Block until a visible element with *text* appears anywhere on page."""
        log.debug("Waiting for text: '%s'", text)
        self._page.get_by_text(text, exact=False).wait_for(
            state="visible", timeout=timeout
        )

    def wait_for_locator_visible(
        self, locator: Locator, timeout: int = Config.ELEMENT_TIMEOUT
    ) -> None:
        """Block until *locator* is visible."""
        locator.wait_for(state="visible", timeout=timeout)

    def wait_for_network_idle(self, timeout: int = Config.NAVIGATION_TIMEOUT) -> None:
        """Block until there are no ongoing network requests."""
        log.debug("Waiting for network idle…")
        self._page.wait_for_load_state("networkidle", timeout=timeout)

    def wait_for_angular(self) -> None:
        """
        Angular-specific: wait until Angular's pending micro-tasks finish.
        Falls back silently if the page is not an Angular app.
        """
        try:
            self._page.evaluate(
                """async () => {
                    if (window.getAllAngularTestabilities) {
                        const testabilities = window.getAllAngularTestabilities();
                        await Promise.all(
                            testabilities.map(t => new Promise(resolve =>
                                t.whenStable(resolve)
                            ))
                        );
                    }
                }"""
            )
        except Exception as exc:
            log.debug("wait_for_angular skipped: %s", exc)


# ══════════════════════════════════════════════════════════════════════════════
# RandomData
# ══════════════════════════════════════════════════════════════════════════════

class RandomData:
    """
    Generate realistic random test data using the Faker library.

    All values are generated fresh on each call, ensuring test isolation.
    """

    @staticmethod
    def first_name() -> str:
        return _fake.first_name()

    @staticmethod
    def last_name() -> str:
        return _fake.last_name()

    @staticmethod
    def email() -> str:
        """Return a unique email guaranteed not to clash with previous runs."""
        return _fake.unique.email()

    @staticmethod
    def strong_password() -> str:
        """Return a password that meets typical HRMS password policies."""
        return f"ValarHR@{_fake.numerify('###')}{_fake.lexify('??').upper()}"

    @staticmethod
    def phone() -> str:
        return _fake.phone_number()

    @staticmethod
    def company() -> str:
        return _fake.company()

    @staticmethod
    def long_string(length: int = 300) -> str:
        return _fake.pystr(min_chars=length, max_chars=length)


# ══════════════════════════════════════════════════════════════════════════════
# SoftAssertions
# ══════════════════════════════════════════════════════════════════════════════

class SoftAssertions:
    """
    Collect multiple assertion failures and report them all at the end of
    a test instead of stopping at the first failure.

    Usage
    -----
        soft = SoftAssertions()
        soft.assert_equal(page.title(), "Welcome", "Page title mismatch")
        soft.assert_true(element.is_visible(), "Element should be visible")
        soft.assert_all()   # raises AssertionError with full summary if any failed
    """

    def __init__(self) -> None:
        self._failures: list[str] = []

    def assert_equal(self, actual: Any, expected: Any, msg: str = "") -> None:
        if actual != expected:
            failure = f"{msg} | Expected: {expected!r}, Got: {actual!r}"
            self._failures.append(failure)
            log.warning("SOFT ASSERT FAILED – %s", failure)

    def assert_true(self, condition: bool, msg: str = "") -> None:
        if not condition:
            self._failures.append(msg or "Condition is False")
            log.warning("SOFT ASSERT FAILED – %s", msg)

    def assert_in(self, member: Any, container: Any, msg: str = "") -> None:
        if member not in container:
            failure = f"{msg} | {member!r} not in {container!r}"
            self._failures.append(failure)
            log.warning("SOFT ASSERT FAILED – %s", failure)

    def assert_all(self) -> None:
        """Raise ``AssertionError`` with all collected failures, if any."""
        if self._failures:
            summary = "\n".join(f"  [{i+1}] {f}" for i, f in enumerate(self._failures))
            raise AssertionError(
                f"{len(self._failures)} soft assertion(s) failed:\n{summary}"
            )
        log.debug("All soft assertions passed.")

"""
utils/logger.py
===============
Centralized, colorised logger for the ValarHR Automation Framework.

Design decisions
----------------
• One Logger per module (standard Python best-practice).
• Console handler uses ``colorlog`` for ANSI colors when stdout is a TTY.
• File handler always writes plain text (no ANSI codes) to reports/framework.log.
• Log level is driven by ``Config.LOG_LEVEL`` so CI can flip it via env-var.

Usage
-----
    from utils.logger import get_logger
    log = get_logger(__name__)
    log.info("Navigating to signup page")
    log.error("Element not found: %s", selector)
"""

import logging
import os
import sys
from pathlib import Path

try:
    import colorlog  # pip install colorlog
    _HAS_COLORLOG = True
except ImportError:
    _HAS_COLORLOG = False

from config.config import Config

# ── Constants ──────────────────────────────────────────────────────────────────
_LOG_FILE = Path(Config.REPORT_DIR) / "framework.log"
_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

_CONSOLE_FORMAT_COLOR = (
    "%(log_color)s%(asctime)s [%(levelname)-8s]%(reset)s "
    "%(cyan)s%(name)s%(reset)s – %(message)s"
)
_CONSOLE_FORMAT_PLAIN = "%(asctime)s [%(levelname)-8s] %(name)s – %(message)s"
_FILE_FORMAT = "%(asctime)s [%(levelname)-8s] %(name)s – %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_LOG_COLORS = {
    "DEBUG":    "white",
    "INFO":     "green",
    "WARNING":  "yellow",
    "ERROR":    "red",
    "CRITICAL": "bold_red",
}

# ── Internal registry (avoid duplicate handlers) ───────────────────────────────
_configured_loggers: set[str] = set()


def get_logger(name: str) -> logging.Logger:
    """
    Return a configured logger for *name*.

    Parameters
    ----------
    name:
        Typically ``__name__`` of the calling module.

    Returns
    -------
    logging.Logger
        Logger with console + file handlers attached (only on first call for
        each unique *name* – subsequent calls return the cached logger).
    """
    logger = logging.getLogger(name)

    if name in _configured_loggers:
        return logger  # handlers already attached

    logger.setLevel(Config.LOG_LEVEL)

    # ── Console handler ────────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(Config.LOG_LEVEL)

    if _HAS_COLORLOG and sys.stdout.isatty():
        console_formatter = colorlog.ColoredFormatter(
            _CONSOLE_FORMAT_COLOR,
            datefmt=_DATE_FORMAT,
            log_colors=_LOG_COLORS,
        )
    else:
        console_formatter = logging.Formatter(_CONSOLE_FORMAT_PLAIN, datefmt=_DATE_FORMAT)

    console_handler.setFormatter(console_formatter)

    # ── File handler ──────────────────────────────────────────────────────────
    file_handler = logging.FileHandler(_LOG_FILE, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)  # always verbose in file
    file_handler.setFormatter(logging.Formatter(_FILE_FORMAT, datefmt=_DATE_FORMAT))

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.propagate = False  # don't bubble up to root logger

    _configured_loggers.add(name)
    return logger

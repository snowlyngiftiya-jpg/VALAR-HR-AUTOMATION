# ValarHR Signup Automation Testing Framework

> **Production-ready** · **Page Object Model** · **Python + Playwright + Pytest**

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Folder Structure](#folder-structure)
3. [Prerequisites](#prerequisites)
4. [Installation](#installation)
5. [Configuration](#configuration)
6. [Running Tests](#running-tests)
7. [Reports](#reports)
8. [Test Cases](#test-cases)
9. [Framework Architecture](#framework-architecture)
10. [Extending to Other Modules](#extending-to-other-modules)
11. [CI/CD Integration](#cicd-integration)

---

## Project Overview

| Item             | Detail                          |
|------------------|---------------------------------|
| Application      | ValarHR HRMS – `https://dev.valarhr.com` |
| Module Tested    | User Signup / Registration      |
| Language         | Python 3.11+                    |
| Browser Automation | Playwright (Sync API)         |
| Test Runner      | Pytest                          |
| Design Pattern   | Page Object Model (POM)         |
| Reporting        | pytest-html (self-contained)    |

---

## Folder Structure

```
ValarHR-Automation/
│
├── pages/
│   ├── __init__.py
│   └── signup_page.py          ← Page Object for Signup page
│
├── tests/
│   ├── __init__.py
│   └── test_signup.py          ← 10 test cases (positive + negative)
│
├── testdata/
│   └── signup_data.json        ← All test data in one place
│
├── config/
│   ├── __init__.py
│   └── config.py               ← Central configuration (URL, browser, timeouts)
│
├── utils/
│   ├── __init__.py
│   ├── logger.py               ← Colourised logger (console + file)
│   ├── screenshot.py           ← Screenshot capture + HTML report attachment
│   └── helpers.py              ← DataLoader, RetryHelper, WaitHelper, RandomData, SoftAssertions
│
├── reports/                    ← Generated HTML reports + log files
├── screenshots/                ← Failure screenshots (PNG)
│
├── conftest.py                 ← Pytest fixtures (browser, page, POM, data)
├── pytest.ini                  ← Pytest configuration
└── requirements.txt            ← Python dependencies
```

---

## Prerequisites

| Requirement | Version |
|-------------|---------|
| Python      | 3.11+   |
| pip         | latest  |
| Git         | any     |

---

## Installation

```bash
# 1. Clone / unzip the framework
git clone <repo-url> ValarHR-Automation
cd ValarHR-Automation

# 2. Create and activate a virtual environment (recommended)
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

# 3. Install Python dependencies
pip install -r requirements.txt

# 4. Install Playwright browsers (Chromium, Firefox, WebKit)
playwright install

# 5. (Optional) Install only Chromium
playwright install chromium
```

---

## Configuration

Edit `config/config.py` **or** set environment variables – no code changes needed for CI:

| Config Key            | Default                           | Env Variable            |
|-----------------------|-----------------------------------|-------------------------|
| `BASE_URL`            | `https://dev.valarhr.com`         | `VALARHR_BASE_URL`      |
| `BROWSER`             | `chromium`                        | `VALARHR_BROWSER`       |
| `HEADLESS`            | `true`                            | `VALARHR_HEADLESS`      |
| `SLOW_MO`             | `0` ms                            | `VALARHR_SLOW_MO`       |
| `LOG_LEVEL`           | `INFO`                            | `VALARHR_LOG_LEVEL`     |

### Example – run against staging in Firefox, headed mode
```bash
VALARHR_BASE_URL=https://staging.valarhr.com \
VALARHR_BROWSER=firefox \
VALARHR_HEADLESS=false \
pytest
```

---

## Running Tests

### Run the full suite
```bash
pytest
```

### Run only smoke tests
```bash
pytest -m smoke
```

### Run only positive tests
```bash
pytest -m positive
```

### Run only negative tests
```bash
pytest -m negative
```

### Run a specific test case
```bash
pytest tests/test_signup.py::TestSignupNegative::test_TC_SU_005_password_mismatch
```

### Run in headed mode (see the browser)
```bash
VALARHR_HEADLESS=false pytest -m smoke -v
```

### Run with slower actions (good for demos)
```bash
VALARHR_HEADLESS=false VALARHR_SLOW_MO=500 pytest
```

### Run in parallel (pytest-xdist)
```bash
pytest -n 4        # 4 workers
pytest -n auto     # 1 worker per CPU core
```

### Run with custom timeout
```bash
pytest --timeout=90
```

---

## Reports

### HTML Report (auto-generated)
```
reports/report.html     ← Open in any browser
reports/framework.log   ← Full debug log
reports/test_run.log    ← Per-test captured log
```

Open the report:
```bash
# macOS
open reports/report.html

# Linux
xdg-open reports/report.html

# Windows
start reports/report.html
```

### Screenshots
Failure screenshots are saved to `screenshots/` automatically and embedded in the HTML report.

---

## Test Cases

| ID         | Description                                  | Type     | Marker            |
|------------|----------------------------------------------|----------|-------------------|
| TC_SU_001  | Successful signup with valid data            | Positive | smoke, positive   |
| TC_SU_002  | Empty required fields                        | Negative | negative          |
| TC_SU_003  | Invalid email formats (4 parametrised)       | Negative | negative          |
| TC_SU_004  | Existing email registration                  | Negative | negative          |
| TC_SU_005  | Password and Confirm Password mismatch       | Negative | negative          |
| TC_SU_006  | Weak / common password                       | Negative | negative          |
| TC_SU_007  | Password shorter than minimum length         | Negative | negative          |
| TC_SU_008  | Maximum field length validation              | Negative | negative          |
| TC_SU_009  | Signup button disabled on empty form         | Negative | negative          |
| TC_SU_010  | SQL / XSS injection in name fields (3 cases) | Negative | negative          |

**Total parametrised test instances: ~16**

---

## Framework Architecture

```
conftest.py
    │
    ├── playwright_instance  (session)
    ├── browser_instance     (session)  ← one browser process
    ├── browser_context      (function) ← isolated per test (like incognito)
    ├── page                 (function) ← fresh tab per test
    ├── signup_page          (function) ← POM instance per test
    ├── test_data            (session)  ← JSON loaded once
    └── screenshot_mgr       (function) ← Screenshot manager per test
            │
            └── pytest_runtest_makereport hook
                    └── auto-capture on failure
```

### Design Decisions

**Playwright Sync API** – Simpler stack traces; no async/await boilerplate. Playwright's internal event loop handles concurrency.

**Function-scope BrowserContext** – Each test gets a completely isolated browser context (cookies, storage, auth).  No test can pollute another.

**Locator strategy** – Prefers ARIA roles and labels (robust, close to how users see the page) over CSS/XPath.  Fallback chain handles Angular-specific attribute patterns.

**Soft Assertions** – `SoftAssertions` collects all failures in a test and reports them together, avoiding the "fix one, find the next" cycle.

**Faker for unique emails** – `RandomData.email()` generates a guaranteed-unique email per run, so the happy-path test never fails because the account already exists.

---

## Extending to Other Modules

To add automation for **Login**:

```
pages/
└── login_page.py      ← new POM

tests/
└── test_login.py      ← new tests
```

`login_page.py` follows the same pattern as `signup_page.py`:
```python
class LoginPage:
    def __init__(self, page: Page): ...
    def open_login_page(self): ...
    def enter_email(self, email): ...
    def enter_password(self, password): ...
    def click_login(self): ...
    def verify_login_success(self): ...
```

Add a `login_page` fixture to `conftest.py`:
```python
@pytest.fixture
def login_page(page):
    return LoginPage(page)
```

The same pattern scales to: Employee Management, Attendance, Leave, Payroll, Approvals, Compensation, Loan, Advance.

---

## CI/CD Integration

### GitHub Actions (`.github/workflows/tests.yml`)

```yaml
name: ValarHR Automation

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.11' }
      - run: pip install -r requirements.txt
      - run: playwright install --with-deps chromium
      - run: pytest -m regression
        env:
          VALARHR_BASE_URL: ${{ secrets.VALARHR_BASE_URL }}
          VALARHR_HEADLESS: true
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: test-report
          path: |
            reports/
            screenshots/
```

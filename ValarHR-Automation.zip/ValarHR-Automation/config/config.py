"""
config/config.py
================
Central configuration module for the ValarHR Automation Framework.

All environment-level settings live here so that:
  • Tests never hard-code URLs, timeouts, or credentials.
  • Switching from dev → staging → prod is a single change.
  • CI/CD pipelines can override values via environment variables.

Usage
-----
    from config.config import Config
    url = Config.BASE_URL
"""

import os
from dataclasses import dataclass, field
from typing import Literal

# ---------------------------------------------------------------------------
# Browser type alias
# ---------------------------------------------------------------------------
BrowserType = Literal["chromium", "firefox", "webkit"]


@dataclass(frozen=True)
class _Config:
    """
    Immutable configuration object.
    All attributes have sensible defaults that can be overridden by
    environment variables so CI/CD pipelines need zero code changes.
    """

    # ── Application ──────────────────────────────────────────────────────────
    BASE_URL: str = field(
        default_factory=lambda: os.getenv("VALARHR_BASE_URL", "https://dev.valarhr.com")
    )
    SIGNUP_PATH: str = "/signup"
    LOGIN_PATH: str = "/login"

    # ── Browser ──────────────────────────────────────────────────────────────
    BROWSER: BrowserType = field(
        default_factory=lambda: os.getenv("VALARHR_BROWSER", "chromium")
    )
    HEADLESS: bool = field(
        default_factory=lambda: os.getenv("VALARHR_HEADLESS", "true").lower() == "true"
    )
    SLOW_MO: int = field(
        default_factory=lambda: int(os.getenv("VALARHR_SLOW_MO", "0"))
    )

    # ── Timeouts (milliseconds) ───────────────────────────────────────────────
    DEFAULT_TIMEOUT: int = 30_000      # Playwright default action timeout
    NAVIGATION_TIMEOUT: int = 60_000   # Page navigation / load timeout
    ELEMENT_TIMEOUT: int = 15_000      # wait_for_selector / locator timeout

    # ── Viewport ─────────────────────────────────────────────────────────────
    VIEWPORT_WIDTH: int = 1920
    VIEWPORT_HEIGHT: int = 1080

    # ── Retry ────────────────────────────────────────────────────────────────
    MAX_RETRIES: int = 3               # pytest-rerunfailures / manual retry
    RETRY_DELAY: float = 1.0           # seconds between retries

    # ── Artifacts ────────────────────────────────────────────────────────────
    SCREENSHOT_DIR: str = "screenshots"
    REPORT_DIR: str = "reports"
    SCREENSHOT_ON_FAILURE: bool = True
    VIDEO_ON_FAILURE: bool = False     # Set True to record video of failed tests

    # ── Test-data file ────────────────────────────────────────────────────────
    TEST_DATA_FILE: str = "testdata/signup_data.json"

    # ── Logging ──────────────────────────────────────────────────────────────
    LOG_LEVEL: str = field(
        default_factory=lambda: os.getenv("VALARHR_LOG_LEVEL", "INFO")
    )

    # ── Derived helpers ───────────────────────────────────────────────────────
    @property
    def signup_url(self) -> str:
        """Full URL for the Signup page."""
        return f"{self.BASE_URL}{self.SIGNUP_PATH}"

    @property
    def login_url(self) -> str:
        """Full URL for the Login page."""
        return f"{self.BASE_URL}{self.LOGIN_PATH}"


# Singleton instance – import and use directly:  `from config.config import Config`
Config = _Config()
